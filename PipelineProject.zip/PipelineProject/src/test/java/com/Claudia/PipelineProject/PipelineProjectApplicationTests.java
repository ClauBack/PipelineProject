package com.Claudia.PipelineProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PipelineProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
